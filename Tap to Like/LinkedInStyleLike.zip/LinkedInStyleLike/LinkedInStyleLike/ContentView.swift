//
//  ContentView.swift
//  LinkedInStyleLike
//
//  Created by Amos Gyamfi on 16.8.2020.
//

import SwiftUI

struct ContentView: View {
    
    @State private var unLiked = true
    @State private var liked = false
    @State private var showText = false
    
    var body: some View {
        ZStack{
        if unLiked{  // Initial state
            HStack {
                
                Text("Like")
                
                Image(systemName: "hand.thumbsup")
                
            }.font(/*@START_MENU_TOKEN@*/.title/*@END_MENU_TOKEN@*/)
        }
        else {  // Final state
            HStack {
                
                // Show text using transparency animation
                Text("Like")
                    .opacity(showText ? 1 : 0)
                    .animation(Animation.easeInOut.delay(0.15))
                    .onAppear(){
                        showText = true
                    }
                
                // Scale the thumb up with spring animation
                Image(systemName: "hand.thumbsup.fill")
                    .scaleEffect(liked ? 1 : 0)
                    .rotationEffect(.degrees(liked ? 0 : -45))
                    .animation(Animation.interpolatingSpring(stiffness: 150, damping: 10).delay(0.15))
                    .onAppear(){
                        liked = true
                    }
                
            }
            .font(.title)
            .foregroundColor(Color(.systemTeal))
            
        }
       
    } // Whole container: Dismiss initial state display final state
    .onTapGesture(count: /*@START_MENU_TOKEN@*/1/*@END_MENU_TOKEN@*/, perform: {
        unLiked = false
    })
        
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
            .preferredColorScheme(/*@START_MENU_TOKEN@*/.dark/*@END_MENU_TOKEN@*/)
    }
}
