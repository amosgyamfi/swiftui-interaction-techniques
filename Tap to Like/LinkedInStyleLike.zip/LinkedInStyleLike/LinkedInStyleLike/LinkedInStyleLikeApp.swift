//
//  LinkedInStyleLikeApp.swift
//  LinkedInStyleLike
//
//  Created by Amos Gyamfi on 16.8.2020.
//

import SwiftUI

@main
struct LinkedInStyleLikeApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
